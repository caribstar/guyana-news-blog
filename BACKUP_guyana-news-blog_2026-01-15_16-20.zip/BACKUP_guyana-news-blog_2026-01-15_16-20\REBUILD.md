﻿# 🇬🇾 GUYANA DAILY BRIEF - COMPLETE REBUILD GUIDE

## Backup Date: 2026-01-15_16-20

---

## 🚀 INSTANT RESTORE

Run this command in the backup folder:
```powershell
.\RESTORE.ps1
```

Site will be running locally in 60 seconds!

---

## 📋 WHAT'S INCLUDED

- ✅ All blog posts and content
- ✅ Custom layouts and templates
- ✅ Static files (images, CSS)
- ✅ Hugo theme (PaperMod)
- ✅ Configuration (hugo.toml)
- ✅ Automation script (hugo-push.ps1)
- ✅ One-command restore script

---

## 🎨 KEY FEATURES

### 1. Dueling Perspectives
   - Uncle Ramesh (Pro-Government)
   - Daily Brief (Opposition Watch)

### 2. Guyana Rising
   - The Guyanese Horizon
   - Patriots' Portfolio

### 3. Entertainment
   - Speedeet & Wilar
   - Daily Laugh

### 4. Newsletter
   - Beehiiv API integrated in layouts/index.html

---

## 🌐 DEPLOYMENT OPTIONS

### GitHub Pages (Free)
1. Push to GitHub
2. Enable Pages in settings
3. Done!

### Netlify (Free)
1. Connect GitHub repo
2. Build: `hugo --gc --minify`
3. Publish: `public`

---

*One People, One Nation, One Destiny* 🇬🇾

**Backup Date:** 2026-01-15_16-20
