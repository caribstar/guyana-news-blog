﻿---
title: "📊 Weekly Roundup"
description: "Your complete week in Guyana news"
---

Everything that happened this week, wrapped up with a bow (and probably some sarcasm).
