---
title: "Thanks for Subscribing! 🎉"
layout: "simple"
---

<div style="text-align: center; padding: 60px 20px; max-width: 600px; margin: 0 auto;">
    <div style="font-size: 72px; margin-bottom: 20px;">✅</div>
    <h1 style="font-size: 36px; margin: 0 0 20px 0; color: #009E60;">You're In!</h1>
    <p style="font-size: 18px; color: #666; line-height: 1.6; margin: 0 0 30px 0;">
        Thanks for subscribing to The Guyana Brief! You'll get your first satirical digest delivered to your inbox by noon (Guyana time).
    </p>
    <p style="font-size: 16px; color: #666; margin: 0 0 40px 0;">
        Check your email for a confirmation (and make sure to check your spam folder just in case).
    </p>
    <a href="/" style="display: inline-block; padding: 15px 40px; background: #009E60; color: white; text-decoration: none; border-radius: 30px; font-weight: bold; font-size: 16px;">
        Back to Homepage
    </a>
</div>
