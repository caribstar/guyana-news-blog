﻿---
title: "De Boys Seh: Wha Speedeet & Wilar Talking About Dis Week"
date: 2026-01-15
draft: false
categories: ["Speedeet & Wilar", "De Boys Seh"]
tags: ["youth", "commentary", "Guyanese-culture", "friendship"]
summary: "Speedeet and Wilar share dem thoughts on cricket, video games, school lunch, and why adults always saying 'back in me days.' Short takes from two 12-year-olds!"
---

*Every week, Speedeet and Wilar give we dem take on wha happening in Guyana from a 12-year-old perspective. No politics, just real talk from de boys!*

---

## 🏏 On Guyana Women Cricket Team Winning

**Speedeet:** Bai, yuh see how de Guyana women cricket team WIN yesterday? Seven runs! Dah was TIGHT!

**Wilar:** Me sister seh she want fuh play cricket now because of dem. She bin practicing bowling in de yard and mash up me father car windscreen.

**Speedeet:** *(laughing)* Yuh father vex?

**Wilar:** He seh if she guh play cricket, she better get GOOD enough fuh pay fuh de windscreen when she turn pro!

**Speedeet:** Imagine if WE could play cricket good like dah. We would deh pon TV and everything!

**Wilar:** You? Yuh cyaan even catch a ball when somebody throw it gentle gentle at yuh.

**Speedeet:** Dah was ONE time! And de sun bin in me eye!

**Wilar:** It bin nighttime, Speedeet.

**Speedeet:** Exactly! Dah is why me couldn't see!

---

## 📱 On Wanting De New Phone

**Wilar:** Yuh see de new Samsung phone everybody talking about?

**Speedeet:** De one wid de big camera? Me cousin in America got one. He send picture and de ting looking NICE!

**Wilar:** Me ask me mother fuh one and she laugh fuh five whole minutes. Den she seh "Yuh think money grow pon tree? Yuh want phone? Go plant a money tree in de backyard!"

**Speedeet:** Me father seh de same ting! He seh "When YOU start paying bills, den YOU can talk about new phone."

**Wilar:** But HOW we supposed fuh pay bills? We TWELVE!

**Speedeet:** Exactly! By de time we old enough fuh pay bills, dah phone guh be OLD NEWS!

**Wilar:** Adults nah understand de STRUGGLE.

**Speedeet:** Facts.

---

## 🍚 On School Lunch

**Speedeet:** Yuh nyam de school lunch today?

**Wilar:** De cook-up rice? YES! Dah was de BEST lunch dis whole term!

**Speedeet:** Miss Sharmila cook-up rice different, boy. She does put coconut milk and PLENTY pigtail. Not like when Miss Jennifer cooking and everything taste like cardboard.

**Wilar:** Yuh know wha me nah understand? How come de SAME ingredients taste different when different people cooking?

**Speedeet:** Is de LOVE, bai. Me grandmother seh yuh got fuh cook wid love. Miss Sharmila cooking wid love. Miss Jennifer cooking like she vex wid de food.

**Wilar:** *(laughing)* She DO always look vex!

**Speedeet:** Next week is Miss Jennifer turn fuh cook again. We better bring sandwich from home.

**Wilar:** Agreed.

---

## 🎮 On Video Games vs Outside

**Speedeet:** Me mother seh me spending too much time playing video games. She seh "Back in ME days, we bin play outside!"

**Wilar:** Me grandmother seh de SAME ting! "Back in me days, we bin climb tree and play cricket in de road!"

**Speedeet:** But den when we GO outside fuh play, she seh "Come inside! Yuh guh get licks from car!" or "Yuh guh fall and mash up yuh foot!" So which one is it?!

**Wilar:** *(laughing)* TRUE! Me mother seh go play outside, but den she seh:
- Don't climb tree
- Don't go in de sun too long
- Don't play in de rain
- Don't go by de canal
- Don't play cricket in de road

**Speedeet:** So basically... don't do ANYTHING fun?

**Wilar:** Exactly! So we go back inside and play FIFA, and den she vex AGAIN!

**Speedeet:** Adults confusing, boy.

---

## 🎓 On Teachers Saying "Dis Going on Yuh Permanent Record"

**Wilar:** Mr. Persaud catch me passing note to Sarah today in class.

**Speedeet:** Wha he seh?

**Wilar:** "Wilar Sharma! Dis behavior is UNACCEPTABLE! Dis going on yuh PERMANENT RECORD!"

**Speedeet:** *(laughing)* De PERMANENT RECORD! Dem always threatening we wid dah!

**Wilar:** Yuh think de permanent record is real?

**Speedeet:** Me big brother seh when he apply fuh university, NOBODY ask about he permanent record. He seh is just a ting teachers seh fuh scare we.

**Wilar:** So we bin STRESSED fuh nothing?!

**Speedeet:** Facts! Me bin worried about me permanent record since standard two when me accidentally knock over de fish tank!

**Wilar:** YOU knock over de fish tank?! Me bin think dah was Andre!

**Speedeet:** Shhh! Dah still deh pon me permanent record!

---

## 🏠 On Having to "Go Say Hi" to Adults

**Speedeet:** Yuh know wha me HATE? When we deh at somebody house and me mother seh "Go say hi to Aunty!"

**Wilar:** And de aunty ALWAYS want fuh:
1. Pinch yuh cheek
2. Comment on how big yuh getting
3. Ask about school
4. Tell story about when yuh was small

**Speedeet:** And YOU cyaan remember half dese people! Dem saying "Remember when yuh was a baby and me change yuh diaper?" and yuh like "Me was a BABY! How me supposed fuh remember?!"

**Wilar:** Den dem get vex if yuh nah remember dem!

**Speedeet:** And den dem ALWAYS ask "Wha yuh want fuh be when yuh grow up?" and yuh better not seh "YouTuber" or "Professional Gamer" because den dem guh give yuh a WHOLE lecture!

**Wilar:** Me uncle ask me dah last week. Me seh "Doctor" and he SMILE. But me nah even want fuh be doctor! Me just seh it so he stop talking!

**Speedeet:** Survival skills, bai. Survival skills.

---

## 🎪 On Mashramani Coming Up

**Wilar:** Yuh going to Mashramani parade next month?

**Speedeet:** If me mother leh me! Last year she seh me too young fuh go without adult.

**Wilar:** But we TWELVE now! We practically adults!

**Speedeet:** Dah is wha me TEL she! She just laugh and seh "Twelve nah grown, is just tall pickney."

**Wilar:** *(laughing)* Yuh mother funny, boy!

**Speedeet:** Yuh think YOUR mother guh leh yuh go?

**Wilar:** If me beg enough, probably. Me grandmother soft. If me help she in de garden fuh two weeks straight, she might seh yes.

**Speedeet:** Tactical begging. Smart.

**Wilar:** Yuh got fuh PLAN dese tings, bai. Cyaan just ask random. Yuh got fuh butter dem up first!

**Speedeet:** Yuh learn from de best! *(grinning)*

---

## 🌧️ On Guyana Weather

**Speedeet:** Rain AGAIN today!

**Wilar:** Me know! And JUST when we was supposed fuh have PE class!

**Speedeet:** PE class is de ONLY good class and de rain had fuh mash it up!

**Wilar:** Yuh know wha crazy? De rain stop EXACTLY when PE class done. Like it KNEW.

**Speedeet:** De weather in Guyana got jokes, boy. Hot hot HOT fuh weeks, den suddenly FLOOD fuh three days straight!

**Wilar:** Me grandfather seh climate change real. He seh when HE bin young, yuh could predict de weather. Now? Anything possible!

**Speedeet:** Me mother just seh "Guyana weather always bin crazy. Carry umbrella AND wear short pants. Be ready fuh everything!"

**Wilar:** *(laughing)* Dah is de Guyana way!

---

## De Bottom Line

Life as a 12-year-old in Guyana is:
- Wanting tings yuh cyaan afford
- Being tell yuh spend too much time inside AND outside
- Permanent records dat probably nah exist
- Cricket dreams
- School lunch lottery
- Weather dat got jokes
- Adults who "back in dem days" everything

But we wouldn't trade it fuh nothing!

---

**Next Week on "De Boys Seh":** Speedeet and Wilar discuss why walking PAST de China shop without buying something is impossible, how come every Guyanese household got at least THREE Tupperware containers wid no lids, and why de ice cream truck ALWAYS come right after yuh done nyam lunch!

---

*Speedeet & Wilar are fictional characters celebrating Guyanese youth culture. Dem observations deh fuh bring smiles and reflect everyday life in Guyana from a pickney perspective.* 🇬🇾

**Got topics yuh want de boys fuh talk about? Leh we know!**
